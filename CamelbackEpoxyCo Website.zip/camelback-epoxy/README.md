# Camelback Epoxy Co. — Website

**camelbackepoxy.com** · WKG LLC · Scottsdale, AZ

---

## 🚀 GitHub Pages Deployment

### Step 1 — Create GitHub repo
1. Go to github.com and sign in
2. Click **New repository**
3. Name it exactly: `camelbackepoxy.github.io`  
   *(or use your username: `yourusername.github.io`)*
4. Set to **Public**
5. Click **Create repository**

### Step 2 — Upload all files
1. In your new repo, click **Add file → Upload files**
2. Drag and drop ALL files and folders from this package:
   - `index.html`
   - `services.html`
   - `gallery.html`
   - `about.html`
   - `contact.html`
   - `faq.html`
   - `service-areas.html`
   - `sitemap.html`
   - `sitemap.xml`
   - `robots.txt`
   - `privacy.html`
   - `thank-you.html`
   - `css/` folder
   - `js/` folder
   - `images/` folder (add your photos here)
3. Click **Commit changes**

### Step 3 — Enable GitHub Pages
1. Go to repo **Settings → Pages**
2. Under **Source**, select **Deploy from branch**
3. Select branch: **main** · Folder: **/ (root)**
4. Click **Save**
5. Your site will be live at `https://camelbackepoxy.github.io` in ~2 minutes

### Step 4 — Connect custom domain (camelbackepoxy.com)
1. In **Settings → Pages**, enter `camelbackepoxy.com` under Custom Domain
2. Save — GitHub creates a `CNAME` file automatically
3. At Namecheap (or your registrar), add these DNS records:
   ```
   Type: A    Host: @    Value: 185.199.108.153
   Type: A    Host: @    Value: 185.199.109.153
   Type: A    Host: @    Value: 185.199.110.153
   Type: A    Host: @    Value: 185.199.111.153
   Type: CNAME  Host: www  Value: camelbackepoxy.github.io
   ```
4. Check **Enforce HTTPS** once DNS propagates (1–24 hours)

---

## 🔧 Setup Checklist After Launch

### Replace placeholders:
- [ ] `(480) 555-0100` → your real phone number (in all HTML files + CSS)
- [ ] `hello@camelbackepoxy.com` → your real email
- [ ] `YOUR_FORM_ID` in `index.html` and `contact.html` → your Formspree form ID
- [ ] Add `GA_MEASUREMENT_ID` for Google Analytics 4 (add script to `<head>` of each page)

### Formspree setup (free estimate forms):
1. Go to formspree.io → Create free account
2. Create a new form → copy your Form ID (looks like `xpzkgvqb`)
3. Replace `YOUR_FORM_ID` in:
   - `index.html` (homepage estimate form)
   - `contact.html` (main estimate form)

### Add your real photos:
Place photos in `/images/` folder. Name them:
- `hero-floor.jpg` — hero background (1920×1080 min, your best work)
- `og-home.jpg` — Open Graph share image (1200×630)
- `favicon.svg` — favicon (simple logo or "C" mark)
- `gallery-1.jpg` through `gallery-9.jpg` — project photos

### Submit to Google Search Console:
1. Go to search.google.com/search-console
2. Add property → URL prefix → `https://camelbackepoxy.com`
3. Verify via HTML file or DNS TXT record
4. Submit sitemap: `https://camelbackepoxy.com/sitemap.xml`

---

## 📁 File Structure

```
camelback-epoxy/
├── index.html          ← Homepage (hero, services, stats, testimonials, form)
├── services.html       ← All services detail + pricing
├── gallery.html        ← Project gallery with type filters
├── about.html          ← Founding story, values, credentials
├── contact.html        ← Full lead gen form + contact info
├── faq.html            ← 13 SEO-rich FAQs with Schema.org markup
├── service-areas.html  ← 8 service area pages w/ local SEO content
├── sitemap.html        ← Human-readable sitemap
├── sitemap.xml         ← XML sitemap for Google/Bing
├── robots.txt          ← Search engine crawl instructions
├── privacy.html        ← Privacy policy
├── thank-you.html      ← Post-form conversion page
├── css/
│   └── style.css       ← Full design system (Desert Luxury aesthetic)
├── js/
│   └── main.js         ← Nav, animations, FAQ accordion, form handling
└── images/             ← Add your photos here
```

---

## 🎨 Design System

**Aesthetic:** Desert Luxury / Industrial Precision  
**Fonts:** Bebas Neue (display) · Barlow Condensed (headings/labels) · Barlow (body)  
**Colors:**
- Obsidian `#0D0D0D` — primary background
- Charcoal `#1A1A1A` — section background
- Sand `#C8A96E` — primary accent (Scottsdale desert)
- Copper `#B87333` — secondary accent
- Cream `#F5F0E8` — text

---

## 📊 SEO Implementation

Every page includes:
- Unique `<title>` tag with target keyword + location
- Meta description under 160 characters
- Canonical URL tag
- Open Graph tags (Facebook/LinkedIn sharing)
- Semantic HTML (`<header>`, `<main>`, `<article>`, `<section>`, `<footer>`)
- Breadcrumb navigation on inner pages
- `robots` meta: `index, follow`

Schema.org structured data:
- `LocalBusiness` on homepage (full business profile, hours, ratings)
- `FAQPage` on faq.html (all 13 FAQs — eligible for Google rich results)
- `Service` on services.html
- `ContactPage` on contact.html

Target keywords:
- Primary: "epoxy flooring Scottsdale" · "garage floor epoxy Scottsdale"
- Secondary: "metallic epoxy Scottsdale" · "commercial epoxy flooring Arizona"
- Local: all 8 service area city + "epoxy flooring" combinations

---

*Built for Camelback Epoxy Co. / WKG LLC · 2026*  
*"Built to Dominate. Built to Exit."*
